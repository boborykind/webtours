Action()
{
	lr_start_transaction("UC01_T01_OpenStartPage");
	
	web_reg_save_param_regexp (
    "ParamName=userSession",
    "RegExp=name=\"userSession\" value=\"([^\"]+)\"/>",
    "Ordinal=1",
	LAST);
	
	web_url("WebTours", 
		"URL={protocol}://{host}:{port}/WebTours/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(10);

	lr_end_transaction("UC01_T01_OpenStartPage",LR_AUTO);

	lr_start_transaction("UC01_T02_Login");

	web_submit_data("login.pl", 
		"Action={protocol}://{host}:{port}/cgi-bin/login.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer={protocol}://{host}:{port}/cgi-bin/nav.pl?in=home", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=userSession", "Value={userSession}", ENDITEM, 
		"Name=username", "Value={login}", ENDITEM, 
		"Name=password", "Value={password}", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		"Name=login.x", "Value=74", ENDITEM, 
		"Name=login.y", "Value=3", ENDITEM, 
		LAST);

	lr_end_transaction("UC01_T02_Login",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("UC01_T03_ChangeTabToFlights");
	
	web_reg_save_param_ex(
		"ParamName=depart",
		"LB=<option value=\"",
        "RB=\">",
        "Ordinal=ALL", 
        LAST);
	
	web_reg_save_param_ex(
		"ParamName=arrive",
		"LB=<option value=\"",
        "RB=\">",
        "Ordinal=ALL", 
        LAST);
	
	web_url("Search Flights Button", 
		"URL={protocol}://{host}:{port}/cgi-bin/welcome.pl?page=search", 
		"TargetFrame=body",
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={protocol}://{host}:{port}/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC01_T03_ChangeTabToFlights",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("UC01_T04_SelectCity");
	
		lr_save_string(lr_paramarr_random("depart"), "depart");
		
		lr_save_string(lr_paramarr_random("arrive"), "arrive");
	
	web_reg_save_param_regexp (
    "ParamName=outboundFlight",
    "RegExp=name=\"outboundFlight\" value=\"([^\"]+)\"",
    "Ordinal=All",
	LAST);
	
	//��������� Price � Cost ���� � �� �� ��������, ������ � ������ ������ ���
		
	web_reg_save_param_regexp(
		"ParamName=Price",
		"RegExp=\"center\">(\\$\\s[0-9]+)",
		"Ordinal=All",
		SEARCH_FILTERS,
		LAST);
		
	web_reg_save_param_regexp(
		"ParamName=Cost",
		"RegExp=name=\"outboundFlight\" value=\"\\d+;([0-9]+)",
		"Ordinal=All",
		SEARCH_FILTERS,
		LAST);
	
	web_submit_data("reservations.pl", 
		"Action={protocol}://{host}:{port}/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer={protocol}://{host}:{port}/cgi-bin/reservations.pl?page=welcome", 
		"Snapshot=t4.inf",
		"Mode=HTML",
		ITEMDATA, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=depart", "Value={depart}", ENDITEM,
		"Name=departDate", "Value={departDate}", ENDITEM, 
		"Name=arrive", "Value={arrive}", ENDITEM,
		"Name=returnDate", "Value={returnDate}", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=seatPref", "Value=Window", ENDITEM, 
		"Name=seatType", "Value=Business", ENDITEM, 
		"Name=.cgifields", "Value=roundtrip", ENDITEM, 
		"Name=.cgifields", "Value=seatType", ENDITEM, 
		"Name=.cgifields", "Value=seatPref", ENDITEM, 
		"Name=findFlights.x", "Value=41", ENDITEM, 
		"Name=findFlights.y", "Value=6", ENDITEM, 
		LAST);
	
	lr_end_transaction("UC01_T04_SelectCity",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("UC01_T05_SelectTicket");
	
	lr_save_string(lr_paramarr_random("outboundFlight"), "outboundFlight");
	
	//����� �������� Price ������� �� ���������� ������
	//� Cost - �� ��� � ������ ����������, ���� ���������� ���������� �� ������, ��� �����������
	
	sBuff = lr_eval_string("{outboundFlight}");
	Token1 = (char *)strtok(sBuff,";");
	Token2 = (char *)strtok(NULL,";");
	Token3 = (char *)strtok(NULL,";");
	
	lr_save_string((Token2), "Price");
	
	lr_save_string(lr_paramarr_random("Cost"), "Cost");
	
	web_submit_data("reservations.pl_2", 
		"Action={protocol}://{host}:{port}/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer={protocol}://{host}:{port}/cgi-bin/reservations.pl", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=outboundFlight", "Value={outboundFlight}", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=seatType", "Value=Business", ENDITEM, 
		"Name=seatPref", "Value=Window", ENDITEM, 
		"Name=reserveFlights.x", "Value=41", ENDITEM, 
		"Name=reserveFlights.y", "Value=6", ENDITEM, 
		LAST);

	lr_end_transaction("UC01_T05_SelectTicket",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("UC01_T06_PaymentDetails");
	
	web_submit_data("reservations.pl_3", 
		"Action={protocol}://{host}:{port}/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer={protocol}://{host}:{port}/cgi-bin/reservations.pl", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=firstName", "Value={firstname}", ENDITEM, 
		"Name=lastName", "Value={secondname}", ENDITEM, 
		"Name=address1", "Value=", ENDITEM, 
		"Name=address2", "Value=", ENDITEM, 
		"Name=pass1", "Value={firstname} {secondname}", ENDITEM, 
		"Name=creditCard", "Value={creditcard}", ENDITEM, 
		"Name=expDate", "Value=", ENDITEM, 
		"Name=oldCCOption", "Value=", ENDITEM, 
		"Name=numPassengers", "Value=1", ENDITEM, 
		"Name=seatType", "Value=Business", ENDITEM, 
		"Name=seatPref", "Value=Window", ENDITEM, 
		"Name=outboundFlight", "Value={outboundFlight}", ENDITEM, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=returnFlight", "Value=", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		"Name=.cgifields", "Value=saveCC", ENDITEM, 
		"Name=buyFlights.x", "Value=54", ENDITEM, 
		"Name=buyFlights.y", "Value=10", ENDITEM, 
		LAST);
	
	lr_end_transaction("UC01_T06_PaymentDetails",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("UC01_T07_ChangeTabToItinerary");

	web_url("Itinerary Button", 
		"URL={protocol}://{host}:{port}/cgi-bin/welcome.pl?page=itinerary", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={protocol}://{host}:{port}/cgi-bin/nav.pl?page=menu&in=flights", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC01_T07_ChangeTabToItinerary",LR_AUTO);

	lr_think_time(10);

	lr_start_transaction("UC01_T08_Logout");

	web_url("SignOff Button", 
		"URL={protocol}://{host}:{port}/cgi-bin/welcome.pl?signOff=1", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={protocol}://{host}:{port}/cgi-bin/nav.pl?page=menu&in=itinerary", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("UC01_T08_Logout",LR_AUTO);

	return 0;
}